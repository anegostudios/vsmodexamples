dotnet run --project ZZCakeBuild/CakeBuild.csproj -- $args
exit $LASTEXITCODE;